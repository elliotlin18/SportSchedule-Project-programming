import csv        # Import the csv module for parsing CSV file
import datetime      
# Function to format performance values for display
def format_performance(discipline, value):
    """
    Format performance value based on discipline type.
    Returns a nicely formatted string.
    """
    if discipline in ['100m', '200m', '400m', '800m', '1600m']:
        # Running events - show time in seconds with 2 decimals
        return f"{value:.2f}s"
    elif discipline in ['LJ', 'TJ', 'HJ', 'PV']:
        # Jumping events - show distance/height in meters with 2 decimals
        return f"{value:.2f}m"
    else:
        return str(value)
# List of event codes/names that are treated as numeric results
stages = ['LJ', "TJ", 'HJ', 'PV', '100m', '200m', '400m', '800m', '1600m']  # disciplines treated as numeric

# The filename to read (path relative to the current working directory)
filename = "athletes.csv"  # CSV file containing athlete rows

def read_file():
    # Create an empty dict that will hold all athletes
    all_athletes = {}  # main dict: {athlete_name: {discipline: value, ...}, ...}

    # Open the file in read mode; 'with' ensures the file is closed automatically
    with open(filename, "r", newline='') as infile:
        # Create a csv.reader that correctly handles splitting columns
        reader = csv.reader(infile)

        # Try to read the first row as header; StopIteration means empty file
        try:
            # Read the header row and remove extra whitespace around each field
            header = [h.strip() for h in next(reader)]  # header is a list of column names
        except StopIteration:
            # If the file is empty, return the empty dict
            return all_athletes

        # Iterate over the remaining rows in the CSV file
        for row in reader:
            # Skip completely empty rows
            if not row:
                continue  # skip blank lines

            # Remove leading/trailing whitespace in each cell
            data = [cell.strip() for cell in row]  # cleaned row cells

            # The first column is assumed to be the athlete's name (if present)
            athlete_name = data[0] if len(data) > 0 else ""  # name or empty string
            # Skip the row if the name is missing or empty
            if athlete_name == "":
                continue  # ignore rows without a name

            # Create an empty dict to store this athlete's data
            athlete_data = {}  # store discipline: value pairs for this athlete

            # Loop over column indices for all columns after the name column
            for i in range(1, len(header)):
                # If the row has fewer columns than the header, skip that column
                if i >= len(data):
                    continue  # missing cell; skip

                # Get the column header and the cell text
                discipline = header[i].strip()  # header name for this column
                result_str = data[i]  # raw cell string

                # Skip empty cells
                if result_str == "":
                    continue  # no value for this discipline

                # Try to convert the cell to an appropriate data type
                try:
                    # If the column is "Age", convert to int
                    if discipline == "Age":
                        result = int(result_str)  # convert age to integer
                    # If the column is an event in stages, interpret as float
                    elif discipline in stages:
                        result = float(result_str)  # convert performance to float
                    # Otherwise keep as string
                    else:
                        result = result_str  # keep original string
                except ValueError:
                    # If conversion fails, skip this value
                    continue  # non-numeric where numeric expected

                # Save the converted value in the athlete's data under the column name
                athlete_data[discipline] = result  # store parsed value

            # After processing all columns for this athlete, insert into the main dict
            all_athletes[athlete_name] = athlete_data  # add athlete entry

    # Return the dict with all loaded athletes
    return all_athletes  # final result of read_file()

# PART 2 OF THE PROJECT STARTS HERE:
def build_schedule(all_athletes, events):
    print("Building competition schedule...")  # status message

    # Stations map: each station holds a list representing occupancy per time slot
    stations = {
        "LJ1": [],   # long jump pit 1 occupancy list
        "LJ2": [],   # long jump pit 2 occupancy list
        "HJ1": [],   # high jump area 1 occupancy list
        "HJ2": [],   # high jump area 2 occupancy list
        "PV1": [],   # pole vault area occupancy list
        "Track": []  # track occupancy list (all running events)
    }
    
    athlete_schedule = {}  # map athlete name -> their schedule list
    for name in all_athletes:
        athlete_schedule[name] = []  # initialize each athlete with empty schedule
    
    final_schedule = []  # list of booking tuples (time_slot, station, discipline, athlete, performance)
    conflicts = [] #List to hold conflicts that could interfere with scheduling


    event_order = {"LJ": 1, "TJ": 2, "HJ": 3, "PV": 4, "100m": 5, "200m": 6, "400m": 7, "800m": 8, "1600m": 9}  # preferred event order
    bookings_to_schedule = []  # list of (order, athlete_name, discipline, performance) tuples to schedule

    # Collect all bookings with order first so we can sort globally
    for athlete_name, athlete_data in all_athletes.items():
        for discipline, pr in athlete_data.items():
            # Debug: print what we're processing
            print(f"Checking discipline: '{discipline}' (in stages: {discipline in stages}, in event_order: {discipline in event_order})")
            # Skip non-event fields like Age, Sex, Country
            if discipline not in stages and discipline not in event_order:
                print(f"  -> SKIPPING '{discipline}'")
                continue  # ignore non-competition columns
            order = event_order.get(discipline, 99)  # get order, default to 99 if not found
            bookings_to_schedule.append((order, athlete_name, discipline, pr))

    # Sort by event order, then by athlete name, then by discipline for deterministic scheduling
    bookings_to_schedule.sort(key=lambda x: (x[0], x[1], x[2]))

    # Sort by number of events per athlete (fewer first for better parallelization)
    athlete_event_counts = {name: len([d for d in data.keys() if d in stages]) 
                            for name, data in all_athletes.items()}
    
    # Sort by: athlete event count (ascending), then event order, then athlete name
    bookings_to_schedule.sort(key=lambda x: (athlete_event_counts[x[1]], x[0], x[1], x[2]))

    # Track heat assignments for running events: {discipline: [(time_slot, [athletes]), ...]}
    track_heats = {}
    max_heat_size = 8  # Maximum athletes per heat for running events
    
    # Track which time slots are used by which running distance
    track_schedule = {}  # {time_slot: discipline} - only one distance per slot

    # Iterate bookings in sorted order and place each booking at the earliest available slot/station
    for order, athlete_name, discipline, pr in bookings_to_schedule:
        # Determine if this is a running event
        is_running = discipline in ['100m', '200m', '400m', '800m', '1600m']
        
        if discipline == "LJ" or discipline == "TJ":
            possible_stations = ["LJ1", "LJ2"]
        elif discipline == "HJ":
            possible_stations = ["HJ1", "HJ2"]
        elif discipline == "PV":
            possible_stations = ["PV1"]
        else:
            possible_stations = ["Track"]

        time_slot = 0  # start searching at time slot 0
        found_station = False  # flag to stop when booking is placed

        # Search for the earliest free time slot and station for this athlete/discipline
        while not found_station:
            # Athlete is busy at this time if their schedule already has an entry at time_slot and it's not FREE
            is_athlete_busy = time_slot < len(athlete_schedule[athlete_name]) and athlete_schedule[athlete_name][time_slot] != "FREE"

            # Only try to place booking if athlete is free at this time slot
            if not is_athlete_busy:
                # For field events with multiple stations, try to balance usage
                # Check which station has fewer bookings at current time slot
                if len(possible_stations) > 1 and not is_running:
                    # Count usage at this time slot for each station
                    station_usage = {}
                    for st in possible_stations:
                        usage = sum(1 for b in final_schedule if b[0] == time_slot and b[1] == st)
                        station_usage[st] = usage
                    # Sort stations by usage (least used first)
                    possible_stations = sorted(possible_stations, key=lambda st: station_usage.get(st, 0))
                
                for station in possible_stations:
                    # For running events, check if we can add to existing heat or station has space
                    if is_running and station == "Track":
                        # Check if this time slot already has a running event scheduled
                        if time_slot in track_schedule:
                            # Time slot is occupied - check if it's the same discipline
                            if track_schedule[time_slot] != discipline:
                                # Different running distance - slot is busy for this discipline
                                is_station_busy = True
                            else:
                                # Same discipline - check if heat has space
                                existing_count = sum(1 for b in final_schedule 
                                                   if b[0] == time_slot and b[1] == "Track" and b[2] == discipline)
                                if existing_count < max_heat_size:
                                    is_station_busy = False
                                else:
                                    is_station_busy = True
                        else:
                            # No running events at this slot - it's free
                            is_station_busy = False
                    else:
                        # Field events: Station is busy if already occupied at this time
                        # Check if the time slot exists in the list AND is not FREE
                        if time_slot < len(stations[station]):
                            is_station_busy = stations[station][time_slot] != "FREE"
                        else:
                            is_station_busy = False

                    if not is_station_busy:
                        # Fill up athlete schedule with "FREE" placeholders until time_slot index exists
                        while len(athlete_schedule[athlete_name]) < time_slot:
                            athlete_schedule[athlete_name].append("FREE")
                        
                        # Ensure station list has enough slots up to and including this time_slot
                        while len(stations[station]) <= time_slot:
                            stations[station].append("FREE")
                        
                        # Mark station as occupied at this specific time slot
                        if not is_running:
                            stations[station][time_slot] = athlete_name  # Set at specific index
                        else:
                            stations[station][time_slot] = "HEAT"  # Mark running heat at specific index

                        # Add the booking to athlete schedule
                        athlete_schedule[athlete_name].append(f"{discipline} @ {station}")  # readable entry

                        # Create booking tuple and append to final schedule
                        booking = (time_slot, station, discipline, athlete_name, pr)
                        final_schedule.append(booking)

                        # Track heat assignments for running events
                        if is_running:
                            # Mark this time slot as used by this discipline
                            track_schedule[time_slot] = discipline
                            heat_key = (discipline, time_slot)
                            if heat_key not in track_heats:
                                track_heats[heat_key] = []
                            track_heats[heat_key].append(athlete_name)

                        found_station = True  # booking placed
                        break  # exit station loop

            # Increase time_slot for the next iteration if not yet found
            time_slot = time_slot + 1

    # Print completion message with total bookings created



    athlete_conflicts = detect_conflicts(final_schedule)
    if athlete_conflicts:
      conflicts.extend(athlete_conflicts)
      print(f"WARNING: {len(athlete_conflicts) } athlete scheduling conflicts detected!")
      for conflict in athlete_conflicts:
        print(f" - {conflict}")


    print(f"Finished building competition schedule. Total {len(final_schedule)} bookings.")
    print(f"Total time slots used: {max((b[0] for b in final_schedule), default=0) + 1}")
    
    # Print heat summary for running events
    if track_heats:
        print("\nRunning Event Heats Summary:")
        for (discipline, time_slot), athletes in sorted(track_heats.items()):
            print(f"  {discipline} at slot {time_slot}: {len(athletes)} athletes (Heat)")
    
    return final_schedule  # return the list of bookings





def detect_conflicts(final_schedule):
    """
    Detect scheduling conflicts: same athlete booked more than once in the same timeslot.
    final_schedule is list of tuples (time_slot, station, discipline, athlete, pr).
    Returns list of conflict descriptions.
    """
    conflicts = []
    # map (athlete, time_slot) -> list of bookings
    by_athlete_slot = {}
    for time_slot, station, discipline, athlete_name, pr in final_schedule:
        key = (athlete_name, time_slot)
        by_athlete_slot.setdefault(key, []).append((station, discipline))

    for (athlete_name, time_slot), bookings in by_athlete_slot.items():
        if len(bookings) > 1:
            conflicts.append(f"{athlete_name} has {len(bookings)} bookings at timeslot {time_slot}: {bookings}")

    return conflicts


def minimize_competition_time(final_schedule):
    """
    Compute simple statistics about the final schedule: total slots used and station utilization.
    Returns a dict with keys: total_slots, total_bookings, station_utilization, average_utilization.
    """
    if not final_schedule:
        return {}

    max_slot = max(b[0] for b in final_schedule)
    total_slots_needed = max_slot + 1

    # Count actual station usage (not individual athletes)
    station_utilization = {}
    station_slot_usage = set()  # Track unique (station, time_slot) combinations
    
    for booking in final_schedule:
        station = booking[1]
        time_slot = booking[0]
        
        # Count total bookings per station
        station_utilization[station] = station_utilization.get(station, 0) + 1
        
        # Track unique station-slot combinations (for utilization calculation)
        station_slot_usage.add((station, time_slot))

    # Calculate utilization based on actual station-slot usage, not individual athletes
    total_stations = len(station_utilization) if station_utilization else 1
    total_available_slots = total_slots_needed * total_stations
    actual_slots_used = len(station_slot_usage)
    average_utilization = actual_slots_used / total_available_slots

    stats = {
        "total_slots": total_slots_needed,
        "total_bookings": len(final_schedule),
        "station_utilization": station_utilization,
        "average_utilization": average_utilization,
        "actual_station_slots_used": actual_slots_used
    }
    return stats


def write_schedule_to_file(final_schedule, output_filename):
    # Print status about writing file
    print(f"Writing competition schedule to file... {output_filename}...")

    # Sort schedule comprehensively:
    # 1. Time slot (ascending)
    # 2. Discipline order (running events in order, then field events)
    # 3. Station (Track first, then LJ/HJ/PV)
    # 4. Performance (fastest/best first within each heat/event)
    
    discipline_order = {
        "100m": 1, "200m": 2, "400m": 3, "800m": 4, "1600m": 5,
        "LJ": 6, "TJ": 7, "HJ": 8, "PV": 9
    }
    
    station_order = {"Track": 0, "LJ1": 1, "LJ2": 2, "HJ1": 3, "HJ2": 4, "PV1": 5}
    
    # Sort by: time_slot, discipline_order, station, then performance (best first)
    # For running events (lower time is better), for field events (higher distance/height is better)
    def sort_key(booking):
        time_slot, station, discipline, athlete_name, pr = booking
        is_running = discipline in ['100m', '200m', '400m', '800m', '1600m']
        # For running: sort ascending (faster times first), for field: descending (longer/higher first)
        performance_sort = pr if is_running else -pr
        return (time_slot, discipline_order.get(discipline, 99), station_order.get(station, 99), performance_sort)
    
    final_schedule.sort(key=sort_key)

    # Define start time and interval between time slots
    start_time = datetime.datetime(2025, 1, 1, 9, 0)  # Start at 9:00 AM
    interval_minutes = 15  # Each time slot is 15 minutes

    # Compute statistics for the schedule
    stats = minimize_competition_time(final_schedule)

    # Open output file for writing with UTF-8 encoding for Swedish characters
    with open(output_filename, "w", encoding='utf-8') as outfile:
        # Define column widths for fixed-width formatting
        col_widths = [10, 12, 10, 12, 12, 25, 12]
        col_names = ["Timeslot", "Start Time", "Station", "Discipline", "Heat/Lane", "Athlete", "Performance"]
        
        # Write header row with proper spacing
        header_line = ""
        for i, name in enumerate(col_names):
            header_line += name.ljust(col_widths[i])
        outfile.write(header_line + "\n")
        outfile.write("-" * sum(col_widths) + "\n")  # Separator line

        # Track heats for labeling: {(discipline, time_slot): heat_number}
        heat_numbers = {}
        current_heat_num = {}  # {discipline: current_heat_counter}
        
        # Assign heat numbers to running events
        for booking in final_schedule:
            time_slot, station, discipline, athlete_name, pr = booking
            if discipline in ['100m', '200m', '400m', '800m', '1600m']:
                heat_key = (discipline, time_slot)
                if heat_key not in heat_numbers:
                    if discipline not in current_heat_num:
                        current_heat_num[discipline] = 1
                    else:
                        current_heat_num[discipline] += 1
                    heat_numbers[heat_key] = current_heat_num[discipline]

        # Write each booking with proper column alignment
        current_slot = -1
        for booking in final_schedule:
            time_slot, station, discipline, athlete_name, pr = booking  # unpack tuple

            # Add section header and blank row between different time slots for readability
            if time_slot != current_slot:
                if current_slot != -1:
                    outfile.write("\n")  # Empty row separator
                # Add timeslot header (display as 1-indexed for readability)
                slot_start = start_time + datetime.timedelta(minutes=time_slot * interval_minutes)
                time_str_header = slot_start.strftime("%H:%M")
                outfile.write(f"\nTimeslot {time_slot + 1}: {time_str_header}\n")
                outfile.write("-" * sum(col_widths) + "\n")
                current_slot = time_slot

            # Calculate readable start time for this slot
            slot_start = start_time + datetime.timedelta(minutes=time_slot * interval_minutes)
            time_str = slot_start.strftime("%H:%M")  # Format as HH:MM

            # Format performance value (remove unnecessary decimals)
            if isinstance(pr, float):
                performance_str = f"{pr:.2f}"  # Show 2 decimal places
            else:
                performance_str = str(pr)

            # Determine heat/lane label
            if discipline in ['100m', '200m', '400m', '800m', '1600m']:
                heat_key = (discipline, time_slot)
                heat_label = f"Heat {heat_numbers[heat_key]}"
            else:
                heat_label = ""  # No heat for field events

            # Write row with proper column alignment
            row_data = [str(time_slot), time_str, station, discipline, heat_label, athlete_name, performance_str]
            line = ""
            for i, value in enumerate(row_data):
                line += value.ljust(col_widths[i])
            outfile.write(line + "\n")

        # Write schedule statistics section
        outfile.write("\n" + "=" * sum(col_widths) + "\n")
        outfile.write("SCHEDULE STATISTICS\n")
        outfile.write("=" * sum(col_widths) + "\n\n")
        outfile.write(f"Total bookings: {len(final_schedule)}\n")
        outfile.write(f"Total Time Slots Needed: {stats.get('total_slots', 0)}\n")
        outfile.write(f"Schedule Duration (minutes): {stats.get('total_slots', 0) * interval_minutes}\n")

        if final_schedule:
            end_time = start_time + datetime.timedelta(minutes=stats.get('total_slots', 0) * interval_minutes)
            outfile.write(f"Schedule Start Time: {start_time.strftime('%H:%M')}\n")
            outfile.write(f"Competition End Time: {end_time.strftime('%H:%M')}\n")

        outfile.write("\nStation Utilization:\n")
        for station in sorted(stats.get("station_utilization", {}).keys()):
            bookings = stats["station_utilization"][station]
            outfile.write(f"  {station}: {bookings} bookings\n")

        outfile.write(f"\nAverage Utilization: {stats.get('average_utilization', 0.0):.2%}\n")

    # Confirmation message
    print("Competition schedule written to file.")
    print(f"Schedule optimized to {stats.get('total_slots', 0)} time slots ({stats.get('total_slots', 0) * interval_minutes} minutes).")

# Main execution: read data, build schedule, write output
if __name__ == "__main__":
    athletes = read_file()
    print(f"Loaded {len(athletes)} athletes")
    # Debug: print all unique disciplines found
    all_disciplines = set()
    for athlete_data in athletes.values():
        all_disciplines.update(athlete_data.keys())
    print(f"Disciplines found in CSV: {sorted(all_disciplines)}")
    
    if athletes:
        schedule = build_schedule(athletes, stages)
        write_schedule_to_file(schedule, "schedule.csv")

