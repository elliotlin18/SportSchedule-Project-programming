from graphics import *  # Import all names from the graphics module (may cause name collisions)
import csv        # Import the csv module for parsing CSV file
import datetime      
# Function to format performance values for display
def format_performance(discipline, value):
    """
    Format performance value based on discipline type.
    Returns a nicely formatted string.
    """
    if discipline in ['100', '200', '400', '800', '1600']:
        # Running events - show time in seconds with 2 decimals
        return f"{value:.2f}s"
    elif discipline in ['LJ', 'TJ', 'HJ', 'PV']:
        # Jumping events - show distance/height in meters with 2 decimals
        return f"{value:.2f}m"
    else:
        return str(value)
# List of event codes/names that are treated as numeric results
stages = ['LJ', "TJ", 'HJ', 'PV', '100', '200', '400', '800', '1600']  # disciplines treated as numeric

# The filename to read (path relative to the current working directory)
filename = "athletes.csv"  # CSV file containing athlete rows

def read_file():
    # Create an empty dict that will hold all athletes
    all_athletes = {}  # main dict: {athlete_name: {discipline: value, ...}, ...}

    # Open the file in read mode; 'with' ensures the file is closed automatically
    with open(filename, "r", newline='') as infile:
        # Create a csv.reader that correctly handles splitting columns
        reader = csv.reader(infile)

        # Try to read the first row as header; StopIteration means empty file
        try:
            # Read the header row and remove extra whitespace around each field
            header = [h.strip() for h in next(reader)]  # header is a list of column names
        except StopIteration:
            # If the file is empty, return the empty dict
            return all_athletes

        # Iterate over the remaining rows in the CSV file
        for row in reader:
            # Skip completely empty rows
            if not row:
                continue  # skip blank lines

            # Remove leading/trailing whitespace in each cell
            data = [cell.strip() for cell in row]  # cleaned row cells

            # The first column is assumed to be the athlete's name (if present)
            athlete_name = data[0] if len(data) > 0 else ""  # name or empty string
            # Skip the row if the name is missing or empty
            if athlete_name == "":
                continue  # ignore rows without a name

            # Create an empty dict to store this athlete's data
            athlete_data = {}  # store discipline: value pairs for this athlete

            # Loop over column indices for all columns after the name column
            for i in range(1, len(header)):
                # If the row has fewer columns than the header, skip that column
                if i >= len(data):
                    continue  # missing cell; skip

                # Get the column header and the cell text
                discipline = header[i].strip()  # header name for this column
                result_str = data[i]  # raw cell string

                # Skip empty cells
                if result_str == "":
                    continue  # no value for this discipline

                # Try to convert the cell to an appropriate data type
                try:
                    # If the column is "Age", convert to int
                    if discipline == "Age":
                        result = int(result_str)  # convert age to integer
                    # If the column is an event in stages, interpret as float
                    elif discipline in stages:
                        result = float(result_str)  # convert performance to float
                    # Otherwise keep as string
                    else:
                        result = result_str  # keep original string
                except ValueError:
                    # If conversion fails, skip this value
                    continue  # non-numeric where numeric expected

                # Save the converted value in the athlete's data under the column name
                athlete_data[discipline] = result  # store parsed value

            # After processing all columns for this athlete, insert into the main dict
            all_athletes[athlete_name] = athlete_data  # add athlete entry

    # Return the dict with all loaded athletes
    return all_athletes  # final result of read_file()

# PART 2 OF THE PROJECT STARTS HERE:
def build_schedule(all_athletes, events):
    print("Building competition schedule...")  # status message

    # Stations map: each station holds a list representing occupancy per time slot
    stations = {
        "LJ1": [],   # long jump pit 1 occupancy list
        "LJ2": [],   # long jump pit 2 occupancy list
        "HJ1": [],   # high jump area 1 occupancy list
        "HJ2": [],   # high jump area 2 occupancy list
        "PV1": [],   # pole vault area occupancy list
        "Track": []  # track occupancy list (all running events)
    }
    
    athlete_schedule = {}  # map athlete name -> their schedule list
    for name in all_athletes:
        athlete_schedule[name] = []  # initialize each athlete with empty schedule
    
    final_schedule = []  # list of booking tuples (time_slot, station, discipline, athlete, performance)
    conflicts = [] #List to hold conflicts that could interfere with scheduling


    event_order = {"LJ": 1, "TJ": 2, "HJ": 3, "PV": 4, "100": 5, "200": 6, "400": 7, "800": 8, "1600": 9}  # preferred event order
    bookings_to_schedule = []  # list of (order, athlete_name, discipline, performance) tuples to schedule

    # Collect all bookings with order first so we can sort globally
    for athlete_name, athlete_data in all_athletes.items():
        for discipline, pr in athlete_data.items():
            # Debug: print what we're processing
            print(f"Checking discipline: '{discipline}' (in stages: {discipline in stages}, in event_order: {discipline in event_order})")
            # Skip non-event fields like Age, Sex, Country
            if discipline not in stages and discipline not in event_order:
                print(f"  -> SKIPPING '{discipline}'")
                continue  # ignore non-competition columns
            order = event_order.get(discipline, 99)  # get order, default to 99 if not found
            bookings_to_schedule.append((order, athlete_name, discipline, pr))

    # Sort by event order, then by athlete name, then by discipline for deterministic scheduling
    bookings_to_schedule.sort(key=lambda x: (x[0], x[1], x[2]))

    # Sort by number of events per athlete (fewer first for better parallelization)
    athlete_event_counts = {name: len([d for d in data.keys() if d in stages]) 
                            for name, data in all_athletes.items()}
    
    # Sort by: athlete event count (ascending), then event order, then athlete name
    bookings_to_schedule.sort(key=lambda x: (athlete_event_counts[x[1]], x[0], x[1], x[2]))

    # Iterate bookings in sorted order and place each booking at the earliest available slot/station
    for order, athlete_name, discipline, pr in bookings_to_schedule:
        if discipline == "LJ" or discipline == "TJ":
            possible_stations = ["LJ1", "LJ2"]
        elif discipline == "HJ":
            possible_stations = ["HJ1", "HJ2"]
        elif discipline == "PV":
            possible_stations = ["PV1"]
        else:
            possible_stations = ["Track"]

        time_slot = 0  # start searching at time slot 0
        found_station = False  # flag to stop when booking is placed

        # Search for the earliest free time slot and station for this athlete/discipline
        while not found_station:
            # Athlete is busy at this time if their schedule already has an entry at time_slot and it's not FREE
            is_athlete_busy = time_slot < len(athlete_schedule[athlete_name]) and athlete_schedule[athlete_name][time_slot] != "FREE"

            # Only try to place booking if athlete is free at this time slot
            if not is_athlete_busy:
                for station in possible_stations:
                    # Station is busy at this time if its list already has an entry at time_slot and it's not FREE
                    is_station_busy = time_slot < len(stations[station]) and stations[station][time_slot] != "FREE"

                    if not is_station_busy:
                        # Fill up athlete and station lists with "FREE" placeholders until time_slot index exists
                        while len(athlete_schedule[athlete_name]) < time_slot:
                            athlete_schedule[athlete_name].append("FREE")
                        while len(stations[station]) < time_slot:
                            stations[station].append("FREE")

                        # Add the booking to athlete schedule and station occupancy
                        athlete_schedule[athlete_name].append(f"{discipline} @ {station}")  # readable entry
                        stations[station].append(athlete_name)  # station occupied by athlete at this slot

                        # Create booking tuple and append to final schedule
                        booking = (time_slot, station, discipline, athlete_name, pr)
                        final_schedule.append(booking)

                        found_station = True  # booking placed
                        break  # exit station loop

            # Increase time_slot for the next iteration if not yet found
            time_slot = time_slot + 1

    # Print completion message with total bookings created



    athlete_conflicts = detect_conflicts(final_schedule)
    if athlete_conflicts:
      conflicts.extend(athlete_conflicts)
      print(f"WARNING: {len(athlete_conflicts) } athlete scheduling conflicts detected!")
      for conflict in athlete_conflicts:
        print(f" - {conflict}")


    print(f"Finished building competition schedule. Total {len(final_schedule)} bookings.")
    print(f"Total time slots used: {max((b[0] for b in final_schedule), default=0) + 1}") 
    return final_schedule  # return the list of bookings





def detect_conflicts(final_schedule):
    """
    Detect scheduling conflicts: same athlete booked more than once in the same timeslot.
    final_schedule is list of tuples (time_slot, station, discipline, athlete, pr).
    Returns list of conflict descriptions.
    """
    conflicts = []
    # map (athlete, time_slot) -> list of bookings
    by_athlete_slot = {}
    for time_slot, station, discipline, athlete_name, pr in final_schedule:
        key = (athlete_name, time_slot)
        by_athlete_slot.setdefault(key, []).append((station, discipline))

    for (athlete_name, time_slot), bookings in by_athlete_slot.items():
        if len(bookings) > 1:
            conflicts.append(f"{athlete_name} has {len(bookings)} bookings at timeslot {time_slot}: {bookings}")

    return conflicts


def minimize_competition_time(final_schedule):
    """
    Compute simple statistics about the final schedule: total slots used and station utilization.
    Returns a dict with keys: total_slots, total_bookings, station_utilization, average_utilization.
    """
    if not final_schedule:
        return {}

    max_slot = max(b[0] for b in final_schedule)
    total_slots_needed = max_slot + 1

    station_utilization = {}
    for booking in final_schedule:
        station = booking[1]
        station_utilization[station] = station_utilization.get(station, 0) + 1

    total_stations = len(station_utilization) if station_utilization else 1
    average_utilization = len(final_schedule) / (total_slots_needed * total_stations)

    stats = {
        "total_slots": total_slots_needed,
        "total_bookings": len(final_schedule),
        "station_utilization": station_utilization,
        "average_utilization": average_utilization
    }
    return stats


def write_schedule_to_file(final_schedule, output_filename):
    # Print status about writing file
    print(f"Writing competition schedule to file... {output_filename}...")

    # Sort schedule by time slot first, then by station name for better readability
    final_schedule.sort(key=lambda b: (b[0], b[1]))

    # Define start time and interval between time slots
    start_time = datetime.datetime(2025, 1, 1, 9, 0)  # Start at 9:00 AM
    interval_minutes = 15  # Each time slot is 15 minutes

    # Compute statistics for the schedule
    stats = minimize_competition_time(final_schedule)

    # Open output file for writing with UTF-8 encoding for Swedish characters
    with open(output_filename, "w", newline='', encoding='utf-8') as outfile:
        # Use csv.writer for proper formatting and quoting
        writer = csv.writer(outfile, quoting=csv.QUOTE_MINIMAL)

        # Write header row with clear column names
        writer.writerow(["Timeslot", "Start Time", "Station", "Discipline", "Athlete", "Performance"])

        # Write each booking as a CSV row
        for booking in final_schedule:
            time_slot, station, discipline, athlete_name, pr = booking  # unpack tuple

            # Calculate readable start time for this slot
            slot_start = start_time + datetime.timedelta(minutes=time_slot * interval_minutes)
            time_str = slot_start.strftime("%H:%M")  # Format as HH:MM

            # Format performance value (remove unnecessary decimals)
            if isinstance(pr, float):
                performance_str = f"{pr:.2f}"  # Show 2 decimal places
            else:
                performance_str = str(pr)

            # Write row with all columns
            writer.writerow([time_slot, time_str, station, discipline, athlete_name, performance_str])

        # Blank line and then schedule statistics
        writer.writerow([])
        writer.writerow(["SCHEDULE STATISTICS"])
        writer.writerow(["Total bookings", len(final_schedule)])
        writer.writerow(["Total Time Slots Needed", stats.get("total_slots", 0)])
        writer.writerow(["Schedule Duration (minutes)", f"{stats.get('total_slots', 0) * interval_minutes}"])

        if final_schedule:
            end_time = start_time + datetime.timedelta(minutes=stats.get('total_slots', 0) * interval_minutes)
            writer.writerow(["Schedule Start Time", start_time.strftime("%H:%M")])
            writer.writerow(["Competition End Time", end_time.strftime("%H:%M")])

        writer.writerow([])
        writer.writerow(["Station Utilization"])
        for station in sorted(stats.get("station_utilization", {}).keys()):
            bookings = stats["station_utilization"][station]
            writer.writerow([station, bookings])

        writer.writerow([])
        writer.writerow(["Average Utilization", f"{stats.get('average_utilization', 0.0):.2%}"])

    # Confirmation message
    print("Competition schedule written to file.")
    print(f"Schedule optimized to {stats.get('total_slots', 0)} time slots ({stats.get('total_slots', 0) * interval_minutes} minutes).")

# Main execution: read data, build schedule, write output
if __name__ == "__main__":
    athletes = read_file()
    print(f"Loaded {len(athletes)} athletes")
    # Debug: print all unique disciplines found
    all_disciplines = set()
    for athlete_data in athletes.values():
        all_disciplines.update(athlete_data.keys())
    print(f"Disciplines found in CSV: {sorted(all_disciplines)}")
    
    if athletes:
        schedule = build_schedule(athletes, stages)
        write_schedule_to_file(schedule, "competition_schedule.csv")

