

stages = ['LJ', "TJ", 'HJ', 'PV', '100m', '200m', '400m', '800m', '1600m']
filename = "athletes.csv"

def read_file():
    """
    Reads the athlete file with manual file handling, as shown in Zelle, Ch 5.9.
    Uses open(), readline(), for-loop on the file object and close().
    Does NOT use 'import csv' or 'with open()'.
    """
 
    all_athletes = {}
    try:
     
        infile = open(filename, "r")
    except FileNotFoundError:

        print("ERROR: Could not find file:", filename)
        return all_athletes
    


    header_line = infile.readline()

     
    if header_line == "":
        infile.close()
        return all_athletes

    
    header_raw = header_line.split(',')
    

    header = []
    for h in header_raw:

        header.append(h.strip())


    for line in infile:
        # Skip empty lines
        if line.strip() == "":
            continue

        data_raw = line.split(',')

        # Build a clean list with data for this row
        data = []
        for cell in data_raw:
            data.append(cell.strip())

        # First column is name
        athlete_name = data[0]
        if athlete_name == "":
            continue

        # Create an empty dictionary for this athlete (Chapter 11.7.1) [cite: 401]
        athlete_data = {}

        # Loop over column indices (Chapter 2.6, 8.1) [cite: 43-46, 243]
        for i in range(1, len(header)):
            if i >= len(data):
                continue

            discipline = header[i]
            result_str = data[i]

            if result_str == "":
                continue

            # try...except for type conversion (Chapter 7.4) [cite: 223-226]
            try:
                # if-elif-else (Chapter 7.3) [cite: 221-223]
                if discipline == "Age":
                    result = int(result_str)    # int() (Chapter 3.2) [cite: 63]
                elif discipline in stages:      # 'in' operator (Chapter 8.4) [cite: 257]
                    result = float(result_str)  # float() (Chapter 3.2) [cite: 63]
                else:
                    result = result_str
            except ValueError:
                continue

            # Add to athlete's dictionary (Chapter 11.7.1) [cite: 401-402]
            athlete_data[discipline] = result

        all_athletes[athlete_name] = athlete_data
    infile.close()
    return all_athletes



def build_schedule(all_athletes, events):
    """
    This is the advanced scheduling logic.
    It uses only lists, dictionaries and loops, which is
    in accordance with Zelle's book (especially Chapters 11 and 12).
    It fulfills advanced requirements #1 (optimization) and #2 (heats).
    """
    print("Building competition schedule...")


    stations = {
        "LJ1": [], "LJ2": [], "HJ1": [], "HJ2": [], "PV1": [], "Track": []
    }
    athlete_schedule = {}
    for name in all_athletes.keys(): # .keys() (Chapter 11.7.2) [cite: 403]
        athlete_schedule[name] = []
    
    final_schedule = []
    
    # --- Start of Advanced Function #1 & #2 Logic ---

    # Sort to optimize the schedule (Advanced requirement #1) 
    
    # 1. Collect all bookings to be made
    event_order = {"LJ": 1, "TJ": 2, "HJ": 3, "PV": 4, "100m": 5, "200m": 6, "400m": 7, "800m": 8, "1600m": 9}
    bookings_to_schedule = []
    
    for athlete_name, athlete_data in all_athletes.items(): # .items() (Ch 11.7.2) [cite: 403]
        for discipline, pr in athlete_data.items():
            if discipline in event_order:
                order = event_order.get(discipline, 99) # .get() (Ch 11.7.2) [cite: 403]
                # We create a tuple (Chapter 11.5.2) [cite: 387]
                bookings_to_schedule.append((order, athlete_name, discipline, pr))

    # 2. Create a dictionary to count athlete's events
    athlete_event_counts = {}
    for name, data in all_athletes.items():
        count = 0
        for discipline in data.keys():
            if discipline in stages:
                count = count + 1
        athlete_event_counts[name] = count

    # 3. "Decorate" the list for sorting (Zelle, Chapter 11.9, Exercise 9) 
    # This replaces the advanced 'lambda' function.
    decorated_bookings = []
    for booking_tuple in bookings_to_schedule:
        # Unpack the tuple (Chapter 11.5.2) [cite: 387]
        order, athlete_name, discipline, pr = booking_tuple
        count = athlete_event_counts[athlete_name]
        # Sort by: 1. Number of events (lowest first), 2. Event order, 3. Name
        decorated_bookings.append((count, order, athlete_name, discipline, pr))

    # 4. Sort the decorated list (Chapter 11.2.2) [cite: 369]
    decorated_bookings.sort()

    # --- Logic for Advanced requirement #2 (Heats) --- [cite: 116-119]
    max_heat_size = 8 # Max 8 athletes per heat
    track_schedule = {} # Keeps track of which event is on the track at a given time
    
    # Group runners per event to create heats
    running_events = {}
    for discipline in ['100m', '200m', '400m', '800m', '1600m']:
        running_events[discipline] = []
    
    # Create heats for running events
    running_heats = []  # List with (discipline, [runners])
    
    for decorated_tuple in decorated_bookings:
        count, order, athlete_name, discipline, pr = decorated_tuple
        if discipline in running_events:
            running_events[discipline].append((athlete_name, pr))
    
    # Split runners into heats
    for discipline, runners in running_events.items():
        if len(runners) == 0:
            continue
        
        heat_number = 0
        while heat_number * max_heat_size < len(runners):
            heat_start = heat_number * max_heat_size
            heat_end = heat_start + max_heat_size
            if heat_end > len(runners):
                heat_end = len(runners)
            
            heat_runners = runners[heat_start:heat_end]
            running_heats.append((discipline, heat_runners))
            heat_number = heat_number + 1
    

    for decorated_tuple in decorated_bookings:
        count, order, athlete_name, discipline, pr = decorated_tuple
        

        if discipline in running_events:
            continue
        
        if discipline == "LJ" or discipline == "TJ":
            possible_stations = ["LJ1", "LJ2"]
        elif discipline == "HJ":
            possible_stations = ["HJ1", "HJ2"]
        elif discipline == "PV":
            possible_stations = ["PV1"]
        else:
            continue

        time_slot = 0
        found_station = False

        # while-loop (Chapter 8.2) [cite: 245]
        while not found_station:
            # Skip blocked time slots
            if is_blocked_timeslot(time_slot):
                time_slot = time_slot + 1
                continue
            
            is_athlete_busy = time_slot < len(athlete_schedule[athlete_name])
            
            # Check warm-up time: athlete needs at least 1 slot gap
            has_warmup_time = True
            if time_slot > 0 and time_slot - 1 < len(athlete_schedule[athlete_name]):
                if athlete_schedule[athlete_name][time_slot - 1] != "FREE":
                    has_warmup_time = False
            
            if not is_athlete_busy and has_warmup_time:
                for station in possible_stations:
                    # Basic station logic [cite: 30]
                    is_station_busy = time_slot < len(stations[station])

                    if not is_station_busy:
                        # Fill with "FREE"
                        while len(athlete_schedule[athlete_name]) <= time_slot:
                            athlete_schedule[athlete_name].append("FREE")
                        while len(stations[station]) <= time_slot:
                            stations[station].append("FREE")

                  
                        athlete_schedule[athlete_name][time_slot] = "{0} @ {1}".format(discipline, station)
                        stations[station][time_slot] = athlete_name
                        
                        booking = (time_slot, station, discipline, athlete_name, pr, None)
                        final_schedule.append(booking)

                        found_station = True
                        break 
            
            time_slot = time_slot + 1 

    heat_counter = {}  # Track heat numbers per discipline
    for discipline in ['100m', '200m', '400m', '800m', '1600m']:
        heat_counter[discipline] = 1
    
    for discipline, heat_runners in running_heats:
        # Find next available time slot for everyone in the heat
        time_slot = 0
        found_slot = False
        
        while not found_slot:
            # Skip blocked time slots
            if is_blocked_timeslot(time_slot):
                time_slot = time_slot + 1
                continue
            
            # Check if time slot is free for all runners in the heat
            all_free = True
            
            # Check if Track is occupied
            if time_slot in track_schedule:
                # Time slot already used, move on
                all_free = False
            
            # Check if all runners are free and have warm-up time
            if all_free:
                for runner_name, runner_pr in heat_runners:
                    if time_slot < len(athlete_schedule[runner_name]):
                        all_free = False
                        break
                    # Check warm-up time: need at least 1 slot gap
                    if time_slot > 0 and time_slot - 1 < len(athlete_schedule[runner_name]):
                        if athlete_schedule[runner_name][time_slot - 1] != "FREE":
                            all_free = False
                            break
            
            if all_free:
                # Get current heat number for this discipline
                current_heat = heat_counter[discipline]
                
                # Book all runners in the heat
                for runner_name, runner_pr in heat_runners:
                    # Fill with "FREE"
                    while len(athlete_schedule[runner_name]) <= time_slot:
                        athlete_schedule[runner_name].append("FREE")
                    while len(stations["Track"]) <= time_slot:
                        stations["Track"].append("FREE")
                    
                    # Book!
                    athlete_schedule[runner_name][time_slot] = "{0} @ Track".format(discipline)
                    
                    # Add heat number to booking
                    booking = (time_slot, "Track", discipline, runner_name, runner_pr, current_heat)
                    final_schedule.append(booking)
                
                track_schedule[time_slot] = discipline
                heat_counter[discipline] = current_heat + 1
                found_slot = True
            else:
                time_slot = time_slot + 1

    # Use .format() 
    msg = "Schedule completed. Total {0} bookings.".format(len(final_schedule))
    print(msg)
    return final_schedule

def is_blocked_timeslot(time_slot):
    """
    Checks if a time slot is blocked for breaks or ceremonies.
    Returns True if blocked, False if available.
    
    Constraints:
    - Lunch break: 12:00-13:00 (slots 12-15, which are 12:00, 12:15, 12:30, 12:45)
    - Award ceremony: 17:30-18:00 (slots 34-35)
    - Night rest: 18:00-09:00 next day (slots 36-59)
    """
    # Calculate time for this slot (handles multi-day)
    total_minutes = time_slot * 15
    day = total_minutes // (24 * 60)  # Which day (0=first day, 1=second day)
    minutes_today = total_minutes % (24 * 60)  # Minutes into current day
    hour = 9 + (minutes_today // 60)  # Start at 9:00 AM
    
    # Handle hours past midnight
    if hour >= 24:
        hour = hour - 24
        day = day + 1
    
    minute = minutes_today % 60
    
    # Lunch break: 12:00-13:00 (4 slots every day)
    if hour == 12:
        return True
    
 
    if hour >= 18 or hour < 9:
        return True
    
    return False

def detect_conflicts(final_schedule):
    """
    Fulfills Advanced requirement #1: "Detect conflicts automatically" 
    """
    print("Running conflict detection...")
    conflicts = []
    by_athlete_slot = {}
    
    for booking_tuple in final_schedule:
        time_slot, station, discipline, athlete_name, pr, heat = booking_tuple
        key = (athlete_name, time_slot)
        
 
        current_bookings = by_athlete_slot.get(key, [])
        current_bookings.append((station, discipline))
        by_athlete_slot[key] = current_bookings

    for key, bookings in by_athlete_slot.items():
        if len(bookings) > 1:
            athlete_name, time_slot = key
            # Use .format() (Chapter 5.8.2) [cite: 154]
            msg = "CONFLICT: {0} has {1} bookings at time {2}: {3}".format(athlete_name, len(bookings), time_slot, bookings)
            conflicts.append(msg)
            
    return conflicts

def calculate_schedule_stats(final_schedule):
    """
    Reports on Advanced requirement #1: "Minimize total competition time" 
    """
    if not final_schedule:
        return {}

    max_slot = -1
    for b in final_schedule:
        if b[0] > max_slot:
            max_slot = b[0]
    total_slots_needed = max_slot + 1

    return {"total_slots": total_slots_needed, "total_bookings": len(final_schedule)}

def write_schedule_to_file(final_schedule, output_filename):
    """
    Writes the schedule to a text file with nice formatting.
    Uses open(), print(file=...), .format() and close().
    """
    print("Writing schedule to file:", output_filename)

    # Open file for writing (Chapter 5.9.2) 
    outfile = open(output_filename, "w")

    # Sort list for readability
    # Uses standard .sort() on the list of tuples, which
    # sorts by first element (time_slot), then second, etc.
    final_schedule.sort() # Sort by time_slot

    # Write header row with fixed width
    header = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
        "Time Slot", "Station", "Event", "Heat", "Athlete", "Record"
    )
    print(header, file=outfile)
    print("=" * 88, file=outfile)
    
    current_slot = -1
    max_slot_in_schedule = max([b[0] for b in final_schedule]) if final_schedule else 0
    
    # Write schedule including breaks and ceremonies
    slot = 0
    current_day = 1
    in_break_period = False
    break_type = ""
    
    while slot <= max_slot_in_schedule:
        # Calculate start time (handles multi-day)
        total_minutes = slot * 15
        day = total_minutes // (24 * 60)  # Which day
        minutes_today = total_minutes % (24 * 60)
        hour = 9 + (minutes_today // 60)
        
        # Handle hours past midnight
        if hour >= 24:
            hour = hour - 24
            day = day + 1
        
        minute = minutes_today % 60
        
        # Check if we've moved to a new day
        if day + 1 > current_day:
            current_day = day + 1
            print("", file=outfile)
            print("="*88, file=outfile)
            day_header = "DAY {0}".format(current_day)
            print(day_header.center(88), file=outfile)
            print("="*88, file=outfile)
            print("", file=outfile)
        
        time_str = "{0:02d}:{1:02d}".format(hour, minute)
        
        # Check if this slot has any bookings
        slot_bookings = [b for b in final_schedule if b[0] == slot]
        
        # Check if this is a blocked slot
        is_blocked = is_blocked_timeslot(slot)
        
        # Determine break type
        current_break_type = ""
        if is_blocked:
            if hour == 12:
                current_break_type = "LUNCH"
            elif hour >= 18 or hour < 9:
                current_break_type = "NIGHT"
        
        # If entering a new break period, write the header
        if is_blocked and not in_break_period:
            in_break_period = True
            break_type = current_break_type
            
            if current_slot != -1:
                print("", file=outfile)
            
            if break_type == "LUNCH":
                print("*** LUNCH BREAK (12:00 - 13:00) ***".center(88), file=outfile)
            elif break_type == "NIGHT":
                print("*** NIGHT REST (18:00 - 09:00) ***".center(88), file=outfile)
            print("-" * 88, file=outfile)
            current_slot = slot
        
        # If exiting a break period, reset flag
        if not is_blocked and in_break_period:
            in_break_period = False
            break_type = ""
        
        # Write regular time slots with bookings
        if len(slot_bookings) > 0 and not is_blocked:
            if current_slot != -1:
                print("", file=outfile)  # Empty line between time slots
            
            slot_header = "Time Slot {0} - Start Time: {1}".format(slot + 1, time_str)
            print(slot_header, file=outfile)
            print("-" * 88, file=outfile)
            current_slot = slot
            
            # Write bookings for this slot
            for booking in slot_bookings:
                # Unpack tuple (Chapter 11.5.2) [cite: 387]
                time, station, discipline, athlete_name, pr, heat = booking
                
                # Format heat display
                heat_str = str(heat) if heat is not None else "-"
                
                # Build row with fixed width for nice column formatting
                line = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
                    time + 1, station, discipline, heat_str, athlete_name, str(pr)
                )
                
                # Write to file (Chapter 5.9.2) [cite: 162]
                print(line, file=outfile)
        
        slot = slot + 1
    
    # Add award ceremony at the end of Day 2
    # Find the last slot time
    if max_slot_in_schedule >= 0:
        total_minutes = max_slot_in_schedule * 15
        day = total_minutes // (24 * 60)
        
        ceremony_start_slot = max_slot_in_schedule + 1
        
        for ceremony_slot in range(ceremony_start_slot, ceremony_start_slot + 2):
            total_minutes = ceremony_slot * 15
            minutes_today = total_minutes % (24 * 60)
            hour = 9 + (minutes_today // 60)
            if hour >= 24:
                hour = hour - 24
            minute = minutes_today % 60
            time_str = "{0:02d}:{1:02d}".format(hour, minute)
            
            print("", file=outfile)
            slot_header = "Time Slot {0} - Start Time: {1}".format(ceremony_slot + 1, time_str)
            print(slot_header, file=outfile)
            print("-" * 88, file=outfile)
            
            ceremony_msg = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
                "", "---", "CEREMONY", "-", "*** AWARD CEREMONY ***", "-"
            )
            print(ceremony_msg, file=outfile)

    outfile.close()
    print("Schedule written to file.")



def main():
    athletes = read_file()
    
 
    if athletes:

        print("Loaded", len(athletes), "athletes")
        
        schedule = build_schedule(athletes, stages)
        
        conflicts = detect_conflicts(schedule)
        if len(conflicts) > 0:
            print("WARNING: The following conflicts were detected:")
            for c in conflicts:
                print(c)
        else:
            print("No conflicts detected.")

    
        stats = calculate_schedule_stats(schedule)
        print("Schedule completed. Total time slots:", stats.get("total_slots", 0))

     
        write_schedule_to_file(schedule, "schedule.csv")
    else:
        print("No athletes loaded, exiting.")

if __name__ == "__main__":
    main()
