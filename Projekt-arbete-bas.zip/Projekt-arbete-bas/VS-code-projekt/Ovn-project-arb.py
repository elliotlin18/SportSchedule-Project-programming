from graphics import *  # Importerar allt från graphics-modulen (kan ge namnkollisioner)
import csv              # Importerar csv-modulen för säker CSV-parsning

# Lista med gren-koder/namn som tolkas som numeriska resultat
stages = ['LJ', "TJ", 'HJ', 'PV', '100', '200', '400', '800', '1600']


# Filnamnet som ska läsas in (sökväg relativ till aktuell working directory)
filename = "athletes.csv"

def read_file():
    # Skapar en tom dict som kommer hålla alla atleter
    all_athletes = {}

    # Öppnar filen i läsläge; with ser till att filen stängs automatiskt
    with open(filename, "r", newline='') as infile:
        # Skapar en csv.reader som hanterar uppdelning av kolumner korrekt
        reader = csv.reader(infile)

        # Försök läsa första raden som rubrik; StopIteration betyder tom fil
        try:
            # Läser rubrikraden och tar bort extra blanksteg runt varje fält
            header = [h.strip() for h in next(reader)]
        except StopIteration:
            # Om filen är tom returnera den tomma dicten
            return all_athletes

        # Itererar över återstående rader i CSV-filen
        for row in reader:
            # Hoppa över helt tomma rader
            if not row:
                continue

            # Ta bort ledande/efterföljande blanksteg i varje cell
            data = [cell.strip() for cell in row]

            # Första kolumnen antas vara idrottarens namn (om den finns)
            athlete_name = data[0] if len(data) > 0 else ""
            # Hoppa över raden om namnet saknas eller är tomt
            if athlete_name == "":
                continue

            # Skapar en tom dict för att lagra denna idrottarens data
            athlete_data = {}

            # Loopar över kolumnindex för alla kolumner efter namnkolumnen
            for i in range(1, len(header)):
                # Om raden har färre kolumner än rubriker, hoppa den kolumnen
                if i >= len(data):
                    continue

                # Hämta kolumnens rubrik och cellens text
                discipline = header[i].strip()
                result_str = data[i]

                # Hoppa tomma celler
                if result_str == "":
                    continue

                # Försök konvertera cellen till lämplig datatyp
                try:
                    # Om kolumnen heter "Age", konvertera till int
                    if discipline == "Age":
                        result = int(result_str)
                    # Om kolumnen är en gren i stages, tolka som float
                    elif discipline in stages:
                        result = float(result_str)
                    # Annars lämna som sträng
                    else:
                        result = result_str
                except ValueError:
                    # Om konvertering misslyckas, hoppa detta värde
                    continue

                # Spara konverterat värde i idrottarens data under kolumnnamnet
                athlete_data[discipline] = result

            # När alla kolumner för denna idrottare behandlats, lägg in i huvud-dict
            all_athletes[athlete_name] = athlete_data

    # Returnera dicten med alla inlästa idrottare
    return all_athletes

# Kör endast läsningen om skriptet körs direkt (inte när det importeras)
if __name__ == "__main__":
    athletes = read_file()
    # Skriv ut hur många idrottare som laddades (antal nycklar i dicten)
    print(f"Loaded {len(athletes)} athletes")


#DEL 2 UTAV PROJEKETET KOMMER HÄR: 
def build_schedule(all_athletes, events):
    print("Bygger tävlingsschema...")

    stations = {
        "LJ1": [],
        "LJ2": [],
        "HJ1": [],
        "HJ2": [],
        "PV1": [],
        "Track": []
    }
    
    athlete_schedule = {}
    for name in all_athletes:
        athlete_schedule[name] = []
    
    final_schedule = []

    for athlete_name, athlete_data in all_athletes.items():
        for discipline, pr in athlete_data.items():
            if discipline == "LJ" or discipline == "TJ":
                possible_stations = ["LJ1", "LJ2"]
            elif discipline == "HJ":
                possible_stations = ["HJ1", "HJ2"]
            elif discipline == "PV":
                possible_stations = ["PV1"]
            else:
                possible_stations = ["Track"]

            time_slot = 0
            found_station = False
            
            while not found_station:
                is_athlete_busy = time_slot < len(athlete_schedule[athlete_name])

                if not is_athlete_busy:
                    for station in possible_stations:
                        is_station_busy = time_slot < len(stations[station])

                        if not is_station_busy:
                            # Fyll upp med "LEDIG" tills vi nått time_slot
                            while len(athlete_schedule[athlete_name]) < time_slot:
                                athlete_schedule[athlete_name].append("LEDIG")
                            while len(stations[station]) < time_slot:
                                stations[station].append("LEDIG")

                            # Lägg till bokingen
                            athlete_schedule[athlete_name].append(f"{discipline} @ {station}")
                            stations[station].append(athlete_name)

                            booking = (time_slot, station, discipline, athlete_name, pr)
                            final_schedule.append(booking)

                            found_station = True
                            break
                
                # Öka time_slot för nästa iteration
                time_slot = time_slot + 1

    print(f"Färdigt tävlingsschema skapat. Total {len(final_schedule)} bokningar.")
    return final_schedule

def write_schedule_to_file(final_schedule, output_filename):
    print(f"Skriver tävlingsschema till fil... {output_filename}...")

    with open(output_filename, "w", newline='') as outfile:
        print("Timeslot,Station,Discipline,Athlete,Performance", file=outfile)

        for booking in final_schedule:
            time, station, discipline, athlete_name, pr = booking
            line = str(time) + "," + station + "," + discipline + "," + athlete_name + "," + str(pr)
            print(line, file=outfile)
        
        print("Färdigt tävlingsschema skrivet till fil.")

if __name__ == "__main__":
    athletes = read_file()
    
    if athletes:
        print(f"Loaded {len(athletes)} athletes")
        schedule = build_schedule(athletes, stages)
        write_schedule_to_file(schedule, "competition_schedule.csv")

