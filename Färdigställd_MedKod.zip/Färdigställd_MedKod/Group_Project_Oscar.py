#Globala variabler och filnamn
stages = ['LJ', "TJ", 'HJ', 'PV', '100m', '200m', '400m', '800m', '1600m']
filename = "athletes.csv"


#funktion för att läsa in filen med atleternas data
def read_file():
    """Läser in data för atleterna genom att läsa av huvudraden och returnerar 
    en ordbok med atleternas namn som nycklar och deras prestationer som värden."""   
    all_athletes = {}
    try:
        infile = open(filename, "r")
    except FileNotFoundError:
        print("ERROR: Could not find file:", filename)
        return all_athletes

    header_line = infile.readline()

     #header innebär huvudraden i csv filen
    if header_line == "":
        infile.close()
        return all_athletes

    # Bygger en list med header kolumner, splittar på kommatecken och tar bort extra mellanslag
    header_raw = header_line.split(',')
    header = []
    for h in header_raw:
        header.append(h.strip())

        
    for line in infile:
        # Skippar dom tomma raderna
        if line.strip() == "":
            continue

        data_raw = line.split(',')

        # Bygger en list med data för varje rad
        data = []
        for cell in data_raw:
            data.append(cell.strip())

        #Första värdet i raden är atletens namn, ifall det är tomt så fortsätter vi till nästa rad
        athlete_name = data[0]
        if athlete_name == "":
            continue

         #skapa en "ordbok" för varje atlet  
        athlete_data = {}

        # Loopar igenom varje kolumn i raden, börjar från index 1 eftersom index 0 är namnet
        for i in range(1, len(header)):
            if i >= len(data):
                continue
        
            #Hämta discipline (aktivitet) och result_str för aktuell kolumn
            discipline = header[i]
            result_str = data[i]


            # Skippar tomma resultat
            if result_str == "":
                continue

            # Konvertera resultatet till rätt datatyp
            try:
               #om discipline är "Age" så konvertera till int, annars om det är i stages så konvertera till float, annars behåll som sträng
                if discipline == "Age":
                    result = int(result_str)    
                elif discipline in stages:      
                    result = float(result_str)  
                else:
                    result = result_str
            except ValueError:
                continue

            # Lägg till discipline och resultat i atletens data "ordbok"
            athlete_data[discipline] = result
        
        # Lägg till atletens data i den övergripande "ordboken" för alla atleter
        all_athletes[athlete_name] = athlete_data
       #stänger filen efter att ha läst in all data 
    infile.close()

    # Returnerar ordboken med alla atleter och deras data
    return all_athletes



def build_schedule(all_athletes, events):

    #För att göra mer inlevelse så skriver vi ut att vi bygger schemat
    print("Building competition schedule...")

    # Initiera datastrukturer för schemaläggning, inklusive stationer och atletens schema, varje station har ett specifikt namn
    stations = {
        "LJ1": [], "LJ2": [], "HJ1": [], "HJ2": [], "PV1": [], "Track": []
    }

    # Atletens schema initieras som en tom lista för varje atlet
    athlete_schedule = {}
    
    #keys står för atleternas namn, ett sorts värde
    for name in all_athletes.keys():
        #gör en tom lista för varje atlet i deras schema
        athlete_schedule[name] = []
    
    #skapar ett tomt schema för den slutgiltiga schemaläggningen
    final_schedule = []
    
   #skapar en lista med bokningar att schemalägga
    event_order = {"LJ": 1, "TJ": 2, "HJ": 3, "PV": 4, "100m": 5, "200m": 6, "400m": 7, "800m": 8, "1600m": 9}
    bookings_to_schedule = []
    
    #skapar en  for loop för att gå igenom alla atleter och deras prestationer, lägger till bokningar för varje disciplin i listan bookings_to_schedule
    for athlete_name, athlete_data in all_athletes.items(): 
        for discipline, pr in athlete_data.items():
            if discipline in event_order:
                order = event_order.get(discipline, 99) 
                bookings_to_schedule.append((order, athlete_name, discipline, pr))

    # 2. Räkna antalet evenemang per atlet inom de angivna disciplinerna (stages)
    athlete_event_counts = {}
    for name, data in all_athletes.items():
        count = 0
        for discipline in data.keys():
            if discipline in stages:
                count = count + 1
        athlete_event_counts[name] = count
#Decorate innebär att vi lägger till extra information till varje bokning för att underlätta sortering, se det som en typ av förberedekse
    decorated_bookings = []
    for booking_tuple in bookings_to_schedule:
        order, athlete_name, discipline, pr = booking_tuple
        count = athlete_event_counts[athlete_name]
        decorated_bookings.append((count, order, athlete_name, discipline, pr))

    # Sortera bokningarna baserat på antalet evenemang (få först) och sedan ordningen av disciplinen, görs genom .sort()
    decorated_bookings.sort()

#Här kommer schemaläggningen för tracjk och fält evenemangen
    
    max_heat_size = 8 
    #skapa en tom ordbok för att hålla reda på schemat för banan
    track_schedule = {}
    
    # Gruppera discipliner för löpning
    running_events = {}
    for discipline in ['100m', '200m', '400m', '800m', '1600m']:
        running_events[discipline] = []
    
    #Skapa en lista för att hålla reda på löpande heat
    running_heats = []  

    #Den här delen grupperar löpare per disciplin för att förbereda dem för heat-indelning
    for decorated_tuple in decorated_bookings:
        count, order, athlete_name, discipline, pr = decorated_tuple
        if discipline in running_events:
            running_events[discipline].append((athlete_name, pr))
    
    # Dela upp löpare i heat baserat på max_heat_size
    for discipline, runners in running_events.items():
        if len(runners) == 0:
            continue

        #while-loop som delar upp löparna i heat
        heat_number = 0
        while heat_number * max_heat_size < len(runners):
            heat_start = heat_number * max_heat_size
            heat_end = heat_start + max_heat_size
            if heat_end > len(runners):
                heat_end = len(runners)
            
            heat_runners = runners[heat_start:heat_end]
            running_heats.append((discipline, heat_runners))
            heat_number = heat_number + 1
    
# förbereder schemaläggning för fält evenemangen
    for decorated_tuple in decorated_bookings:
        count, order, athlete_name, discipline, pr = decorated_tuple
        

        if discipline in running_events:
            continue

        # Bestäm möjliga stationer baserat på disciplin
        if discipline == "LJ" or discipline == "TJ":
            possible_stations = ["LJ1", "LJ2"]
        elif discipline == "HJ":
            possible_stations = ["HJ1", "HJ2"]
        elif discipline == "PV":
            possible_stations = ["PV1"]
        else:
            continue
        
        #Gå tillbaka till vanlig schemaläggning evenmang
        time_slot = 0
        found_station = False

       # while loop för att hitta nästa tillgängliga tidsslot för atleten
        while not found_station:
            if is_blocked_timeslot(time_slot):
                time_slot = time_slot + 1
                continue

            # Kontrollera om atleten är upptagen vid denna tidsslot
            is_athlete_busy = time_slot < len(athlete_schedule[athlete_name])
            
          # Kontrollera om atleten har varm upp tid (minst 1 slot fri innan)
            has_warmup_time = True
            if time_slot > 0 and time_slot - 1 < len(athlete_schedule[athlete_name]):
                if athlete_schedule[athlete_name][time_slot - 1] != "FREE":
                    has_warmup_time = False
            
            if not is_athlete_busy and has_warmup_time:
                for station in possible_stations:
                    is_station_busy = time_slot < len(stations[station])


                    #Om stationen inte är upptagen, boka den för atleten
                    if not is_station_busy:
                        while len(athlete_schedule[athlete_name]) <= time_slot:
                            athlete_schedule[athlete_name].append("FREE")
                        while len(stations[station]) <= time_slot:
                            stations[station].append("FREE")

                        #Boka stationen för atleten
                        athlete_schedule[athlete_name][time_slot] = "{0} @ {1}".format(discipline, station)
                        stations[station][time_slot] = athlete_name

                        # Skapa bokningspost och lägg till i slutgiltiga schemat
                        booking = (time_slot, station, discipline, athlete_name, pr, None)
                        final_schedule.append(booking)

                        found_station = True
                        break 
            
            time_slot = time_slot + 1 


    # Schemalägg löpande heat
    heat_counter = {}  
    for discipline in ['100m', '200m', '400m', '800m', '1600m']:
        heat_counter[discipline] = 1

    #loopar igenom varje heat i running_heats för att schemalägga dem
    for discipline, heat_runners in running_heats:
        time_slot = 0
        found_slot = False
        
        while not found_slot:
            
            # Kontrollera om tidssloten är blockerad
            if is_blocked_timeslot(time_slot):
                time_slot = time_slot + 1
                continue
            
         # Kontrollera om banan är upptagen vid denna tidsslot
            all_free = True
            
           #checkar om banan är upptagen vid denna tidsslot
            if time_slot in track_schedule:
                #om den är upptagen, sätt all_free till False
                all_free = False
            #Undersöker om någon av löparna i heatet är upptagna vid denna tidsslot
            if all_free:
                for runner_name, runner_pr in heat_runners:
                    if time_slot < len(athlete_schedule[runner_name]):
                        all_free = False
                        break

                   #kollar om löparen har varm upp tid (minst 1 slot fri innan)
                    if time_slot > 0 and time_slot - 1 < len(athlete_schedule[runner_name]):
                        if athlete_schedule[runner_name][time_slot - 1] != "FREE":
                            all_free = False
                            break
            #Om både banan och alla löpare är fria vid denna tidsslot, boka heatet
            if all_free:
                current_heat = heat_counter[discipline]
                
                ##Boka varje löpare i heatet
                for runner_name, runner_pr in heat_runners:
                    while len(athlete_schedule[runner_name]) <= time_slot:
                        athlete_schedule[runner_name].append("FREE")
                    while len(stations["Track"]) <= time_slot:
                        stations["Track"].append("FREE")
                    
                   #Boka löparen på banan vid denna tidsslot
                    athlete_schedule[runner_name][time_slot] = "{0} @ Track".format(discipline)
                    
                  #Skapar och sparar bokningsposten i det slutgiltiga schemat
                    booking = (time_slot, "Track", discipline, runner_name, runner_pr, current_heat)
                    final_schedule.append(booking)
                

                #Boka banan vid denna tidsslot
                track_schedule[time_slot] = discipline
                #Uppdatera heat räknaren för disciplinen
                heat_counter[discipline] = current_heat + 1
                found_slot = True
            else:
                #Om inte, gå till nästa tidsslot
                time_slot = time_slot + 1

    # Slutligen, returnera det slutgiltiga schemat
    msg = "Schedule completed. Total {0} bookings.".format(len(final_schedule))
    print(msg)
    return final_schedule


#funktion för att kolla om en tidsslot är blockerad för pauser eller ceremonier
def is_blocked_timeslot(time_slot):
    """Finns flera begränsningar:
    - Tider före 9:00 och efter 18:00 är blockerade varje dag.
    - Lunchrast från 12:00 till 13:00 varje dag.
    - Prisutdelningsceremoni efter tävlingen på dag 2"""

   # om tiden är blockad så returnerar den True, annars False

  # Beräkna starttid för den givna tidssloten, ger timmar och minuter värden  
    total_minutes = time_slot * 15
    day = total_minutes // (24 * 60)  # Which day (0=first day, 1=second day)
    minutes_today = total_minutes % (24 * 60)  # Minutes into current day
    hour = 9 + (minutes_today // 60)  # Start at 9:00 AM
    
    # Hantera timmar efter midnatt
    if hour >= 24:
        hour = hour - 24
        day = day + 1
    
    minute = minutes_today % 60
    
    #Lunch break från 12:00 till 13:00
    if hour == 12:
        return True
    
 #Natt vila från 18:00 till 09:00
    if hour >= 18 or hour < 9:
        return True
    
    return False

# Funktion för att upptäcka konflikter i schemat
def detect_conflicts(final_schedule):
  
  #
    print("Running conflict detection...")
    #skapar en tom lista för att hålla reda på konflikter
    conflicts = []

    #skapar en ordbok för att hålla reda på bokningar per atlet och tidsslot
    by_athlete_slot = {}
    
    #loopar igenom varje bokning i det slutgiltiga schemat
    for booking_tuple in final_schedule:
        time_slot, station, discipline, athlete_name, pr, heat = booking_tuple
        key = (athlete_name, time_slot)
        
        #Hämtar nuvarande bokningar för atleten vid denna tidsslot
        current_bookings = by_athlete_slot.get(key, [])
        current_bookings.append((station, discipline))

        #Uppdaterar ordboken med den nya bokningen
        by_athlete_slot[key] = current_bookings
        
    #kollar efter konflikter i bokningarna
    for key, bookings in by_athlete_slot.items():
        if len(bookings) > 1:
            athlete_name, time_slot = key
            
            #använd format för att skapa en konfliktmeddelande
            msg = "CONFLICT: {0} has {1} bookings at time {2}: {3}".format(athlete_name, len(bookings), time_slot, bookings)
            conflicts.append(msg)
            
    return conflicts

def calculate_schedule_stats(final_schedule):
 
    #returnerar tom ordbok om schemat är tomt
    if not final_schedule:
        return {}


    max_slot = -1

    #hitta den högsta tidssloten i schemat
    for b in final_schedule:
        if b[0] > max_slot:
            max_slot = b[0]
        #Beräknar totala antal tidsslotar som behövs
    total_slots_needed = max_slot + 1

    #Returnerar statistik som en ordbok med hur många bokningar och totala tidsslotar
    return {"total_slots": total_slots_needed, "total_bookings": len(final_schedule)}


#funktionen för att skriva schemat till en fil
def write_schedule_to_file(final_schedule, output_filename):
 
    print("Writing schedule to file:", output_filename)

    ##Öppnar filen för skrivning
    outfile = open(output_filename, "w")

    #Sorterar schemat baserat på tidsslot
    final_schedule.sort() 

    #Skriver rubriker till filen
    header = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
        "Time Slot", "Station", "Event", "Heat", "Athlete", "Record"
    )

    #Skriver header till filen så det blir snyggt formulerat
    print(header, file=outfile)
    print("=" * 88, file=outfile)
    
    #Variabler för att hålla reda på aktuell tidsslot och dag
    current_slot = -1
    max_slot_in_schedule = max([b[0] for b in final_schedule]) if final_schedule else 0
    
    # Skriver schemat inklusive pauser och ceremonier
    slot = 0
    current_day = 1
    in_break_period = False
    break_type = ""
    
    while slot <= max_slot_in_schedule:
        # Beräkna starttid (hanterar flera dagar)
        total_minutes = slot * 15
        day = total_minutes // (24 * 60)  # Which day
        minutes_today = total_minutes % (24 * 60)
        hour = 9 + (minutes_today // 60)
        
     # Hantera timmar efter midnatt
        if hour >= 24:
            hour = hour - 24
            day = day + 1
        
        minute = minutes_today % 60
        
        # kollar om vi har gått in i en ny dag, isåfall skriv dag header som gör det snyggt formaterat
        if day + 1 > current_day:
            current_day = day + 1
            print("", file=outfile)
            print("="*88, file=outfile)
            day_header = "DAY {0}".format(current_day)
            print(day_header.center(88), file=outfile)
            print("="*88, file=outfile)
            print("", file=outfile)



        # Formatera tidsträngen
        time_str = "{0:02d}:{1:02d}".format(hour, minute)
        
        #kollar vilka bokningar som finns för den aktuella tidssloten
        slot_bookings = [b for b in final_schedule if b[0] == slot]
        
        #Kontrollera om tidssloten är blockerad
        is_blocked = is_blocked_timeslot(slot)
        
        #Bestäm vilken typ av paus det är
        current_break_type = ""
        if is_blocked:
            if hour == 12:
                current_break_type = "LUNCH"
            elif hour >= 18 or hour < 9:
                current_break_type = "NIGHT"
        
         #Om vi går in i en pausperiod, skriv ut pausmeddelandet
        if is_blocked and not in_break_period:
            in_break_period = True
            break_type = current_break_type

            # Skriv pausmeddelandet
            if current_slot != -1:
                print("", file=outfile)
            # om break_type är LUNCH så skriv ut lunch paus meddelandet
            if break_type == "LUNCH":
                print("*** LUNCH BREAK (12:00 - 13:00) ***".center(88), file=outfile)
                #  om break_type är NIGHT så skriv ut natt vila meddelandet
            elif break_type == "NIGHT":
                print("*** NIGHT REST (18:00 - 09:00) ***".center(88), file=outfile)
            print("-" * 88, file=outfile)
            current_slot = slot
        
        #Hanterar när vi lämnar en pausperiod
        if not is_blocked and in_break_period:
            in_break_period = False
            break_type = ""
        
        #Skriver ut den aktuella tidssloten och dess bokningar om det finns några
        if len(slot_bookings) > 0 and not is_blocked:
            if current_slot != -1:
                print("", file=outfile)  

            # Format och skriv ut tidsslots header
            slot_header = "Time Slot {0} - Start Time: {1}".format(slot + 1, time_str)
            print(slot_header, file=outfile)
            print("-" * 88, file=outfile)
            current_slot = slot
            
        #Skriver ut varje bokning i den aktuella tidssloten
            for booking in slot_bookings:
               #Packar upp bokningsinformationen
                time, station, discipline, athlete_name, pr, heat = booking
                
               #formaterar heat informationen
                heat_str = str(heat) if heat is not None else "-"
                
              #bygger upp raden att skriva ut
                line = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
                    time + 1, station, discipline, heat_str, athlete_name, str(pr)
                )
                
            #Skriver ut raden till filen
                print(line, file=outfile)
        
        slot = slot + 1
    
    # Lägg till prisutdelningsceremoni efter sista tidssloten
    if max_slot_in_schedule >= 0:
        total_minutes = max_slot_in_schedule * 15
        day = total_minutes // (24 * 60)
        
        ceremony_start_slot = max_slot_in_schedule + 1
        
        # Om den sista tidssloten är på dag 0, sätt ceremoni till dag 2
        for ceremony_slot in range(ceremony_start_slot, ceremony_start_slot + 2):
            total_minutes = ceremony_slot * 15
            minutes_today = total_minutes % (24 * 60)
            hour = 9 + (minutes_today // 60)
            if hour >= 24:
                hour = hour - 24
            minute = minutes_today % 60
            time_str = "{0:02d}:{1:02d}".format(hour, minute)
            

            #Skriver ut ceremoni meddelandet
            print("", file=outfile)
            slot_header = "Time Slot {0} - Start Time: {1}".format(ceremony_slot + 1, time_str)
            print(slot_header, file=outfile)
            print("-" * 88, file=outfile)
            


            ceremony_msg = "{0:<10} {1:<15} {2:<12} {3:<8} {4:<25} {5:<10}".format(
                "", "---", "CEREMONY", "-", "*** AWARD CEREMONY ***", "-"
            )
            print(ceremony_msg, file=outfile)

    outfile.close()
    print("Schedule written to file.")


#Main funktionen som kör programmet
def main():
    athletes = read_file()

    if athletes:
        print("Loaded", len(athletes), "athletes")
        schedule = build_schedule(athletes, stages)
        conflicts = detect_conflicts(schedule)
        if len(conflicts) > 0:
            print("WARNING: The following conflicts were detected:")
            for c in conflicts:
                print(c)
        else:
            print("No conflicts detected.")

        stats = calculate_schedule_stats(schedule)
        print("Schedule completed. Total time slots:", stats.get("total_slots", 0))     
        write_schedule_to_file(schedule, "schedule.csv")
    else:
        print("No athletes loaded, exiting.")

if __name__ == "__main__":
    main()
